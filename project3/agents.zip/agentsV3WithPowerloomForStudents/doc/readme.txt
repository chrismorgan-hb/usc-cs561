I was able to fully implement the Powerloom portions of the Host and the Customer.
I attempted to do some of the waiter, but I was unable to finish in time due to work
conflicts, and the half-implemented code is not runnable because it is so interdependent.
The broken half-implemented code is in WaiterAgent.java.notWorking.
Since I was unable to do the waiter (incl. the FoodOrder), I did not do the CookAgent.
There is also some information in restaurant.plm to support the Waiter.
I'm hoping that the partial code in the Waiter will result in some partial credit.
