package restaurant;


public class Menu {

    public String choices[] = new String[]
	{ "Steak"  ,
	  "Chicken", 
	  "Salad"  , 
	  "Pizza"  };

}
    
