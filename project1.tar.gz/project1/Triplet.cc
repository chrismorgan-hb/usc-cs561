// Triplet.cpp
// Christopher Morgan
// 7468-2726-35
// CSCI 561 Project 1 Fall 2006
//
// Defines city1, city2, dist data structure
//

#include "Triplet.h"

Triplet::Triplet (char c1, char c2, int d) {

	C1 = c1;
	C2 = c2;
	dist = d;
}

Triplet::Triplet() {

}
